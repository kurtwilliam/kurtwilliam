(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
'use strict';

// JavaScript Media Query for Contact scroll bar

$(window).resize(function () {
	scrollFix();
});

function scrollFix() {
	// get initial position of the element
	var scroll = $('.contact').offset().top;

	// get contact form height to offset bottom position
	var contactH = $('.contact').height();

	// assign scroll event listener
	$(window).scroll(function () {
		// get current position, bottom position, and doc height
		var currentScroll = $(window).scrollTop() + 25;
		var bottomScroll = $(window).scrollTop() + $(window).height();
		var docHeight = $(document).height();
		var footerHeight = $('footer').height();
		var contactHeight = $('.contact').height() + 105;
		var bodyW = $('body').width();

		if (bodyW >= 978) {

			// if scroll height is below header and above footer:
			if (currentScroll >= scroll && currentScroll <= docHeight - (footerHeight + contactHeight)) {
				// apply position: fixed if you
				$('.contact').css({
					// scroll to that element or below it
					position: 'fixed',
					bottom: '0',
					width: '300px'
				});
				$('.wrapper').css({
					margin: '25px 0 0 375px'
				});

				// else if the bottom of contact is at the footer:
			} else if (bottomScroll >= docHeight - footerHeight) {
				$('.contact').css({
					// if you scroll above it
					position: 'absolute',
					bottom: footerHeight + 'px',
					top: 'auto',
					left: '0',
					margin: '25px',
					height: 'calc( 100vh - 50px )'
				});

				// else if scroll position is within header:
			} else if (scroll >= currentScroll) {
				// apply position: static
				$('.contact').css({
					position: 'relative',
					margin: '25px',
					bottom: '0'
				});
				$('.wrapper').css({
					margin: '25px'
				});

				// else if the bottom of the document is above the header (to reset fixed pos):
			} else if (bottomScroll <= docHeight - footerHeight) {
				// apply position: fixed
				$('.contact').css({
					position: 'fixed',
					top: '0',
					bottom: '0'
				});
				$('.wrapper').css({
					margin: '25px 0 0 375px',
					width: '100%'
				});
			}
			// If the body is skinnier than 978px put the contact form at the top
		} else {
			$('.contact').css({
				background: '$main2',
				position: 'relative',
				width: 'calc(100% - 50px)',
				margin: '25px',
				height: 'auto',
				bottom: '0'
			});
			$('.wrapper').css({
				margin: '25px',
				width: '100%'
			});
		}
	});
}

// When a link starts with an octothorp and it is clicked, scroll smoothly (over 900ms)
function linkScroll() {
	$('a[href^="#"]').on('click', function (e) {
		e.preventDefault();
		var target = this.hash,
		    $target = $(target);
		$('html, body').stop().animate({
			'scrollTop': $target.offset().top
		}, 900, 'swing', function () {
			window.location.hash = target;
		});
	});
}

// When the document is ready, run these functions
$(document).ready(function () {
	linkScroll();
	scrollFix();
});

},{}]},{},[1])
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCJzcmMvc2NyaXB0cy9hcHAuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7OztBQ0FBOztBQUVBLEVBQUUsTUFBRixFQUFVLE1BQVYsQ0FBaUIsWUFBVTtBQUMxQjtBQUNBLENBRkQ7O0FBSUEsU0FBUyxTQUFULEdBQW9CO0FBQ25CO0FBQ0EsS0FBSSxTQUFTLEVBQUUsVUFBRixFQUFjLE1BQWQsR0FBdUIsR0FBcEM7O0FBRUE7QUFDQSxLQUFJLFdBQVcsRUFBRSxVQUFGLEVBQWMsTUFBZCxFQUFmOztBQUVBO0FBQ0EsR0FBRSxNQUFGLEVBQVUsTUFBVixDQUFpQixZQUFXO0FBQzNCO0FBQ0EsTUFBSSxnQkFBZ0IsRUFBRSxNQUFGLEVBQVUsU0FBVixLQUF3QixFQUE1QztBQUNBLE1BQUksZUFBZSxFQUFFLE1BQUYsRUFBVSxTQUFWLEtBQXdCLEVBQUUsTUFBRixFQUFVLE1BQVYsRUFBM0M7QUFDQSxNQUFJLFlBQVksRUFBRSxRQUFGLEVBQVksTUFBWixFQUFoQjtBQUNBLE1BQUksZUFBZSxFQUFFLFFBQUYsRUFBWSxNQUFaLEVBQW5CO0FBQ0EsTUFBSSxnQkFBZ0IsRUFBRSxVQUFGLEVBQWMsTUFBZCxLQUF1QixHQUEzQztBQUNBLE1BQUksUUFBUSxFQUFFLE1BQUYsRUFBVSxLQUFWLEVBQVo7O0FBRUEsTUFBSSxTQUFTLEdBQWIsRUFBbUI7O0FBRWxCO0FBQ0EsT0FBSSxpQkFBaUIsTUFBakIsSUFBMkIsaUJBQWtCLGFBQWEsZUFBZSxhQUE1QixDQUFqRCxFQUErRjtBQUMvRjtBQUNDLE1BQUUsVUFBRixFQUFjLEdBQWQsQ0FBa0I7QUFDbEI7QUFDQyxlQUFVLE9BRk87QUFHakIsYUFBUSxHQUhTO0FBSWpCLFlBQU07QUFKVyxLQUFsQjtBQU1BLE1BQUUsVUFBRixFQUFjLEdBQWQsQ0FBa0I7QUFDakIsYUFBUTtBQURTLEtBQWxCOztBQUlEO0FBQ0MsSUFiRCxNQWFPLElBQUksZ0JBQWdCLFlBQVksWUFBaEMsRUFBK0M7QUFDckQsTUFBRSxVQUFGLEVBQWMsR0FBZCxDQUFrQjtBQUNqQjtBQUNBLGVBQVUsVUFGTztBQUdqQixhQUFXLFlBQVgsT0FIaUI7QUFJakIsVUFBSyxNQUpZO0FBS2pCLFdBQU0sR0FMVztBQU1qQixhQUFRLE1BTlM7QUFPakIsYUFBTztBQVBVLEtBQWxCOztBQVVEO0FBQ0csSUFaSSxNQVlFLElBQUksVUFBVSxhQUFkLEVBQTZCO0FBQ3BDO0FBQ0QsTUFBRSxVQUFGLEVBQWMsR0FBZCxDQUFrQjtBQUNmLGVBQVUsVUFESztBQUVqQixhQUFRLE1BRlM7QUFHakIsYUFBUTtBQUhTLEtBQWxCO0FBS0EsTUFBRSxVQUFGLEVBQWMsR0FBZCxDQUFrQjtBQUNqQixhQUFRO0FBRFMsS0FBbEI7O0FBSUM7QUFDQyxJQVpNLE1BWUEsSUFBSyxnQkFBZ0IsWUFBWSxZQUFqQyxFQUErQztBQUNyRDtBQUNGLE1BQUUsVUFBRixFQUFjLEdBQWQsQ0FBa0I7QUFDakIsZUFBVSxPQURPO0FBRWpCLFVBQUssR0FGWTtBQUdqQixhQUFRO0FBSFMsS0FBbEI7QUFLQSxNQUFFLFVBQUYsRUFBYyxHQUFkLENBQWtCO0FBQ2pCLGFBQVEsZ0JBRFM7QUFFakIsWUFBTztBQUZVLEtBQWxCO0FBSUU7QUFDSjtBQUNDLEdBckRELE1BcURNO0FBQ0wsS0FBRSxVQUFGLEVBQWMsR0FBZCxDQUFrQjtBQUNqQixnQkFBWSxRQURLO0FBRWpCLGNBQVUsVUFGTztBQUdqQixXQUFPLG1CQUhVO0FBSWpCLFlBQVEsTUFKUztBQUtqQixZQUFRLE1BTFM7QUFNakIsWUFBTztBQU5VLElBQWxCO0FBUUEsS0FBRSxVQUFGLEVBQWMsR0FBZCxDQUFrQjtBQUNqQixZQUFRLE1BRFM7QUFFakIsV0FBTztBQUZVLElBQWxCO0FBSUE7QUFDRCxFQTVFRDtBQTZFQTs7QUFFRDtBQUNBLFNBQVMsVUFBVCxHQUFxQjtBQUNwQixHQUFFLGNBQUYsRUFBa0IsRUFBbEIsQ0FBcUIsT0FBckIsRUFBNkIsVUFBVSxDQUFWLEVBQWE7QUFDekMsSUFBRSxjQUFGO0FBQ0EsTUFBSSxTQUFTLEtBQUssSUFBbEI7QUFBQSxNQUNBLFVBQVUsRUFBRSxNQUFGLENBRFY7QUFFQSxJQUFFLFlBQUYsRUFBZ0IsSUFBaEIsR0FBdUIsT0FBdkIsQ0FBK0I7QUFDOUIsZ0JBQWEsUUFBUSxNQUFSLEdBQWlCO0FBREEsR0FBL0IsRUFFRyxHQUZILEVBRVEsT0FGUixFQUVpQixZQUFZO0FBQzVCLFVBQU8sUUFBUCxDQUFnQixJQUFoQixHQUF1QixNQUF2QjtBQUNBLEdBSkQ7QUFLQSxFQVREO0FBVUE7O0FBRUQ7QUFDQSxFQUFFLFFBQUYsRUFBWSxLQUFaLENBQWtCLFlBQVU7QUFDeEI7QUFDQTtBQUNILENBSEQiLCJmaWxlIjoiZ2VuZXJhdGVkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXNDb250ZW50IjpbIihmdW5jdGlvbiBlKHQsbixyKXtmdW5jdGlvbiBzKG8sdSl7aWYoIW5bb10pe2lmKCF0W29dKXt2YXIgYT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2lmKCF1JiZhKXJldHVybiBhKG8sITApO2lmKGkpcmV0dXJuIGkobywhMCk7dmFyIGY9bmV3IEVycm9yKFwiQ2Fubm90IGZpbmQgbW9kdWxlICdcIitvK1wiJ1wiKTt0aHJvdyBmLmNvZGU9XCJNT0RVTEVfTk9UX0ZPVU5EXCIsZn12YXIgbD1uW29dPXtleHBvcnRzOnt9fTt0W29dWzBdLmNhbGwobC5leHBvcnRzLGZ1bmN0aW9uKGUpe3ZhciBuPXRbb11bMV1bZV07cmV0dXJuIHMobj9uOmUpfSxsLGwuZXhwb3J0cyxlLHQsbixyKX1yZXR1cm4gbltvXS5leHBvcnRzfXZhciBpPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7Zm9yKHZhciBvPTA7bzxyLmxlbmd0aDtvKyspcyhyW29dKTtyZXR1cm4gc30pIiwiLy8gSmF2YVNjcmlwdCBNZWRpYSBRdWVyeSBmb3IgQ29udGFjdCBzY3JvbGwgYmFyXG5cbiQod2luZG93KS5yZXNpemUoZnVuY3Rpb24oKXtcblx0c2Nyb2xsRml4KCk7XG59KVxuXG5mdW5jdGlvbiBzY3JvbGxGaXgoKXtcblx0Ly8gZ2V0IGluaXRpYWwgcG9zaXRpb24gb2YgdGhlIGVsZW1lbnRcblx0bGV0IHNjcm9sbCA9ICQoJy5jb250YWN0Jykub2Zmc2V0KCkudG9wO1xuXG5cdC8vIGdldCBjb250YWN0IGZvcm0gaGVpZ2h0IHRvIG9mZnNldCBib3R0b20gcG9zaXRpb25cblx0bGV0IGNvbnRhY3RIID0gJCgnLmNvbnRhY3QnKS5oZWlnaHQoKTtcblxuXHQvLyBhc3NpZ24gc2Nyb2xsIGV2ZW50IGxpc3RlbmVyXG5cdCQod2luZG93KS5zY3JvbGwoZnVuY3Rpb24oKSB7XG5cdFx0Ly8gZ2V0IGN1cnJlbnQgcG9zaXRpb24sIGJvdHRvbSBwb3NpdGlvbiwgYW5kIGRvYyBoZWlnaHRcblx0XHRsZXQgY3VycmVudFNjcm9sbCA9ICQod2luZG93KS5zY3JvbGxUb3AoKSArIDI1OyBcblx0XHRsZXQgYm90dG9tU2Nyb2xsID0gJCh3aW5kb3cpLnNjcm9sbFRvcCgpICsgJCh3aW5kb3cpLmhlaWdodCgpO1xuXHRcdGxldCBkb2NIZWlnaHQgPSAkKGRvY3VtZW50KS5oZWlnaHQoKTtcblx0XHRsZXQgZm9vdGVySGVpZ2h0ID0gJCgnZm9vdGVyJykuaGVpZ2h0KCk7XG5cdFx0bGV0IGNvbnRhY3RIZWlnaHQgPSAkKCcuY29udGFjdCcpLmhlaWdodCgpKzEwNTtcblx0XHRsZXQgYm9keVcgPSAkKCdib2R5Jykud2lkdGgoKTtcblxuXHRcdGlmIChib2R5VyA+PSA5NzggKSB7XG5cblx0XHRcdC8vIGlmIHNjcm9sbCBoZWlnaHQgaXMgYmVsb3cgaGVhZGVyIGFuZCBhYm92ZSBmb290ZXI6XG5cdFx0XHRpZiAoY3VycmVudFNjcm9sbCA+PSBzY3JvbGwgJiYgY3VycmVudFNjcm9sbCA8PSAoZG9jSGVpZ2h0IC0gKGZvb3RlckhlaWdodCArIGNvbnRhY3RIZWlnaHQpKSkgIHsgXG5cdFx0XHQvLyBhcHBseSBwb3NpdGlvbjogZml4ZWQgaWYgeW91XG5cdFx0XHRcdCQoJy5jb250YWN0JykuY3NzKHsgICAgICAgICAgICAgICAgIFxuXHRcdFx0XHQvLyBzY3JvbGwgdG8gdGhhdCBlbGVtZW50IG9yIGJlbG93IGl0XG5cdFx0XHRcdFx0cG9zaXRpb246ICdmaXhlZCcsXG5cdFx0XHRcdFx0Ym90dG9tOiAnMCcsXG5cdFx0XHRcdFx0d2lkdGg6JzMwMHB4J1xuXHRcdFx0XHR9KTtcblx0XHRcdFx0JCgnLndyYXBwZXInKS5jc3MoeyAgICAgICAgICAgICAgICAgXG5cdFx0XHRcdFx0bWFyZ2luOiAnMjVweCAwIDAgMzc1cHgnXG5cdFx0XHRcdH0pO1xuXG5cdFx0XHQvLyBlbHNlIGlmIHRoZSBib3R0b20gb2YgY29udGFjdCBpcyBhdCB0aGUgZm9vdGVyOlxuXHRcdFx0fSBlbHNlIGlmIChib3R0b21TY3JvbGwgPj0gZG9jSGVpZ2h0IC0gZm9vdGVySGVpZ2h0ICkge1xuXHRcdFx0XHQkKCcuY29udGFjdCcpLmNzcyh7ICAgICAgICAgICAgICAgXG5cdFx0XHRcdFx0Ly8gaWYgeW91IHNjcm9sbCBhYm92ZSBpdFxuXHRcdFx0XHRcdHBvc2l0aW9uOiAnYWJzb2x1dGUnLFxuXHRcdFx0XHRcdGJvdHRvbTogYCR7Zm9vdGVySGVpZ2h0fXB4YCxcblx0XHRcdFx0XHR0b3A6ICdhdXRvJyxcblx0XHRcdFx0XHRsZWZ0OiAnMCcsXG5cdFx0XHRcdFx0bWFyZ2luOiAnMjVweCcsXG5cdFx0XHRcdFx0aGVpZ2h0OidjYWxjKCAxMDB2aCAtIDUwcHggKSdcblx0XHRcdFx0fSk7XG5cdFx0XHRcdFxuXHRcdFx0Ly8gZWxzZSBpZiBzY3JvbGwgcG9zaXRpb24gaXMgd2l0aGluIGhlYWRlcjpcblx0XHQgICB9IGVsc2UgaWYgKHNjcm9sbCA+PSBjdXJyZW50U2Nyb2xsKSB7XG5cdFx0ICAgLy8gYXBwbHkgcG9zaXRpb246IHN0YXRpY1xuXHRcdFx0XHQkKCcuY29udGFjdCcpLmNzcyh7ICAgICAgICAgICAgICAgXG5cdFx0XHRcdCAgIHBvc2l0aW9uOiAncmVsYXRpdmUnLFxuXHRcdFx0XHRcdG1hcmdpbjogJzI1cHgnLFxuXHRcdFx0XHRcdGJvdHRvbTogJzAnXG5cdFx0XHRcdH0pO1xuXHRcdFx0XHQkKCcud3JhcHBlcicpLmNzcyh7ICAgICAgICAgICAgICAgICBcblx0XHRcdFx0XHRtYXJnaW46ICcyNXB4J1xuXHRcdFx0XHR9KTtcblxuXHRcdCAgIC8vIGVsc2UgaWYgdGhlIGJvdHRvbSBvZiB0aGUgZG9jdW1lbnQgaXMgYWJvdmUgdGhlIGhlYWRlciAodG8gcmVzZXQgZml4ZWQgcG9zKTpcblx0XHQgICB9IGVsc2UgaWYgKCBib3R0b21TY3JvbGwgPD0gZG9jSGVpZ2h0IC0gZm9vdGVySGVpZ2h0KSB7XG5cdFx0ICAgXHQvLyBhcHBseSBwb3NpdGlvbjogZml4ZWRcblx0XHRcdFx0JCgnLmNvbnRhY3QnKS5jc3MoeyAgICAgICAgICAgICAgICAgXG5cdFx0XHRcdFx0cG9zaXRpb246ICdmaXhlZCcsXG5cdFx0XHRcdFx0dG9wOiAnMCcsXG5cdFx0XHRcdFx0Ym90dG9tOiAnMCdcblx0XHRcdFx0fSk7XG5cdFx0XHRcdCQoJy53cmFwcGVyJykuY3NzKHsgICAgICAgICAgICAgICAgIFxuXHRcdFx0XHRcdG1hcmdpbjogJzI1cHggMCAwIDM3NXB4Jyxcblx0XHRcdFx0XHR3aWR0aDogJzEwMCUnXG5cdFx0XHRcdH0pO1xuXHRcdCAgIH1cblx0XHQvLyBJZiB0aGUgYm9keSBpcyBza2lubmllciB0aGFuIDk3OHB4IHB1dCB0aGUgY29udGFjdCBmb3JtIGF0IHRoZSB0b3Bcblx0XHR9IGVsc2V7XG5cdFx0XHQkKCcuY29udGFjdCcpLmNzcyh7ICAgICAgICAgICAgICAgICBcblx0XHRcdFx0YmFja2dyb3VuZDogJyRtYWluMicsXG5cdFx0XHRcdHBvc2l0aW9uOiAncmVsYXRpdmUnLFxuXHRcdFx0XHR3aWR0aDogJ2NhbGMoMTAwJSAtIDUwcHgpJyxcblx0XHRcdFx0bWFyZ2luOiAnMjVweCcsXG5cdFx0XHRcdGhlaWdodDogJ2F1dG8nLFxuXHRcdFx0XHRib3R0b206JzAnXG5cdFx0XHR9KTtcblx0XHRcdCQoJy53cmFwcGVyJykuY3NzKHsgICAgICAgICAgICAgICAgIFxuXHRcdFx0XHRtYXJnaW46ICcyNXB4Jyxcblx0XHRcdFx0d2lkdGg6ICcxMDAlJ1xuXHRcdFx0fSk7XG5cdFx0fVxuXHR9KTtcbn1cblxuLy8gV2hlbiBhIGxpbmsgc3RhcnRzIHdpdGggYW4gb2N0b3Rob3JwIGFuZCBpdCBpcyBjbGlja2VkLCBzY3JvbGwgc21vb3RobHkgKG92ZXIgOTAwbXMpXG5mdW5jdGlvbiBsaW5rU2Nyb2xsKCl7XG5cdCQoJ2FbaHJlZl49XCIjXCJdJykub24oJ2NsaWNrJyxmdW5jdGlvbiAoZSkge1xuXHRcdGUucHJldmVudERlZmF1bHQoKTtcblx0XHRsZXQgdGFyZ2V0ID0gdGhpcy5oYXNoLFxuXHRcdCR0YXJnZXQgPSAkKHRhcmdldCk7XG5cdFx0JCgnaHRtbCwgYm9keScpLnN0b3AoKS5hbmltYXRlKHtcblx0XHRcdCdzY3JvbGxUb3AnOiAkdGFyZ2V0Lm9mZnNldCgpLnRvcCBcblx0XHR9LCA5MDAsICdzd2luZycsIGZ1bmN0aW9uICgpIHtcblx0XHRcdHdpbmRvdy5sb2NhdGlvbi5oYXNoID0gdGFyZ2V0O1xuXHRcdH0pO1xuXHR9KTtcbn1cblxuLy8gV2hlbiB0aGUgZG9jdW1lbnQgaXMgcmVhZHksIHJ1biB0aGVzZSBmdW5jdGlvbnNcbiQoZG9jdW1lbnQpLnJlYWR5KGZ1bmN0aW9uKCl7XG4gICAgbGlua1Njcm9sbCgpO1xuICAgIHNjcm9sbEZpeCgpO1xufSk7ICJdfQ==
